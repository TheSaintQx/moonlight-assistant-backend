'use strict';
const assert = require('node:assert/strict');
const corePath = require.resolve('../moon-vision-core.js');
let seen = null;
require.cache[corePath] = {
  id: corePath,
  filename: corePath,
  loaded: true,
  exports: {
    handler: async event => {
      seen = JSON.parse(event.body);
      return {
        statusCode: 200,
        body: JSON.stringify({ status: 'done', text: 'ok' })
      };
    }
  }
};
const adapter = require('../index.js');

(async () => {
  const result = await adapter.handler({
    body: JSON.stringify({
      action: 'ask', token: 'test-token',
      q: 'Кто такой Геральт?', cid: 'c-adapter-track',
      uid: 'u-' + 'a'.repeat(24), game: 'ведьмак 3', skillTrack: true
    })
  });
  assert.equal(result.status, 'done');
  assert.equal(seen && seen.skillTrack, true);
  assert.equal(seen && seen.cid, 'c-adapter-track');
  console.log('PASS async-adapter-skilltrack-smoke: async adapter forwards skillTrack into Vision core');
})().catch(error => {
  console.error(error);
  process.exitCode = 1;
});
