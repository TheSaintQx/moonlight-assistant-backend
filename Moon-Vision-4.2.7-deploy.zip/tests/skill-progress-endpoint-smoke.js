'use strict';
const assert = require('node:assert/strict');
process.env.AUTH_TOKEN = 'test-moon-token';
process.env.ACCESS_KEY_ID = 'test-access';
process.env.SECRET_ACCESS_KEY = 'test-secret';
process.env.BUCKET = 'moon-assistant';
process.env.KB_URL = 'https://ke.test/function';
process.env.KB_TOKEN = 'test-kb-token';
process.env.YC_API_KEY = 'test-yc-key';
process.env.MODEL_URI = 'gpt://test-folder/qwen/latest';
const core = require('../moon-vision-core.js');

const uid = 'u-' + 'a'.repeat(24);
let stored = {
  qid: 123,
  answers: {
    '123': {
      status: 'processing_deep', q: 'Who is Geralt?', game: 'ведьмак 3',
      cid: 'c-skill-progress-123', uid, skillTrack: true,
      skillDeliveredStages: [], createdAt: Math.floor(Date.now() / 1000) - 10,
      createdAtMs: Date.now() - 10000,
      quick: { text: 'Краткий ответ.', unk: false, src: 'kb' }
    }
  },
  users: { [uid]: { game: 'ведьмак 3', gameSetAt: Date.now() } }
};
let etag = 1;
const oldFetch = global.fetch;

global.fetch = async (url, options = {}) => {
  const u = new URL(String(url));
  if (u.hostname !== 'storage.yandexcloud.net') throw new Error('Unexpected host: ' + u.hostname);
  if (options.method === 'GET') {
    return new Response(JSON.stringify(stored), {
      status: 200, headers: { etag: '"state-' + etag + '"' }
    });
  }
  if (options.method === 'PUT') {
    stored = JSON.parse(Buffer.from(options.body).toString('utf8'));
    etag++;
    return new Response('', { status: 200, headers: { etag: '"state-' + etag + '"' } });
  }
  throw new Error('Unexpected S3 method: ' + options.method);
};

function request(qp) {
  return {
    httpMethod: 'GET',
    headers: { 'X-Moon-Token': process.env.AUTH_TOKEN },
    queryStringParameters: Object.assign({ uid }, qp)
  };
}
async function call(qp) {
  const response = await core.handler(request(qp));
  assert.equal(response.statusCode, 200);
  return JSON.parse(response.body);
}

(async () => {
  try {
    const quick = await call({ skillprogress: '1' });
    assert.equal(quick.status, 'processing_deep');
    assert.equal(quick.stage, 'quick');
    assert.equal(quick.deep_pending, true);
    assert.equal(quick.skill_tracked, true);
    assert.equal(quick.skill_delivered, false);
    assert.equal(quick.game, 'ведьмак 3');

    const ackQuick = await call({
      skillack: '1', cid: 'c-skill-progress-123', stage: 'quick'
    });
    assert.equal(ackQuick.status, 'ok');

    const afterQuick = await call({ skillprogress: '1' });
    assert.equal(afterQuick.status, 'deep_pending', 'quick must not replay while deep is running');
    assert.equal(afterQuick.delivered, true);
    assert.equal(afterQuick.cid, 'c-skill-progress-123');

    // Deep stage becomes independently available after quick was acknowledged.
    stored.answers['123'].status = 'deep_ready';
    stored.answers['123'].text = 'Полный глубокий ответ.';
    stored.answers['123'].doneAt = Math.floor(Date.now() / 1000);
    stored.answers['123'].doneAtMs = Date.now();
    const deep = await call({ skillprogress: '1' });
    assert.equal(deep.status, 'done');
    assert.equal(deep.stage, 'deep');
    assert.equal(deep.skill_delivered, false);

    const ackDeep = await call({
      skillack: '1', cid: 'c-skill-progress-123', stage: 'deep'
    });
    assert.equal(ackDeep.status, 'ok');
    const afterDeep = await call({ skillprogress: '1' });
    assert.equal(afterDeep.status, 'none', 'the delivered deep stage must not be replayed');
    assert.equal(afterDeep.game, 'ведьмак 3', 'game context must be present even when no response is pending');

    // Overlay progress remains independent from the voice-delivery marker.
    const overlay = await call({ progress: '1' });
    assert.equal(overlay.status, 'done');
    assert.equal(overlay.stage, 'deep');


    // Old unfinished tasks expire instead of being revived by skillprogress.
    stored.answers = {};
    stored.qid = 124;
    stored.answers['124'] = {
      status: 'processing_deep', q: 'old pending', game: 'ведьмак 3',
      cid: 'c-old-pending-124', uid, skillTrack: true,
      skillDeliveredStages: [], createdAt: Math.floor(Date.now() / 1000) - 310,
      createdAtMs: Date.now() - 310000,
      quick: { text: '', unk: false }
    };
    const expired = await call({ skillprogress: '1' });
    assert.equal(expired.status, 'expired');
    assert.equal(expired.game, 'ведьмак 3');
    assert.equal(stored.answers['124'].status, 'expired');

    // A quick answer that was never spoken is preserved once when deep misses TTL.
    stored.answers = {};
    stored.qid = 125;
    stored.answers['125'] = {
      status: 'processing_deep', q: 'old quick', game: 'ведьмак 3',
      cid: 'c-old-quick-125', uid, skillTrack: true,
      skillDeliveredStages: [], createdAt: Math.floor(Date.now() / 1000) - 310,
      createdAtMs: Date.now() - 310000,
      quick: { text: 'Краткий ответ до истечения глубокого этапа.', unk: false }
    };
    const quickFallback = await call({ skillprogress: '1' });
    assert.equal(quickFallback.status, 'done');
    assert.equal(quickFallback.stage, 'quick');
    assert.equal(quickFallback.deep_pending, false);
    assert.equal(quickFallback.deep_fallback, true);
    const quickFallbackAck = await call({
      skillack: '1', cid: 'c-old-quick-125', stage: 'quick'
    });
    assert.equal(quickFallbackAck.status, 'ok');
    const afterQuickFallbackAck = await call({ skillprogress: '1' });
    assert.equal(afterQuickFallbackAck.status, 'deep_expired');

    // Final deep answers remain retrievable even if the user follows up late.
    stored.answers = {};
    stored.qid = 126;
    stored.answers['126'] = {
      status: 'deep_ready', q: 'late final', game: 'ведьмак 3',
      cid: 'c-late-final-126', uid, skillTrack: true,
      skillDeliveredStages: [], createdAt: Math.floor(Date.now() / 1000) - 600,
      createdAtMs: Date.now() - 600000,
      text: 'Глубокий ответ, завершённый до проверки.', unk: false, src: 'kb'
    };
    const lateFinal = await call({ skillprogress: '1' });
    assert.equal(lateFinal.status, 'done');
    assert.equal(lateFinal.stage, 'deep');
    assert.equal(lateFinal.game, 'ведьмак 3');

    console.log('PASS skill-progress-endpoint-smoke: CID recovery, game-context restore, stale-task expiry, late final delivery, quick fallback, one-time delivery');
  } finally {
    global.fetch = oldFetch;
  }
})().catch(error => {
  console.error(error);
  process.exitCode = 1;
}).finally(() => {
  global.fetch = oldFetch;
});
