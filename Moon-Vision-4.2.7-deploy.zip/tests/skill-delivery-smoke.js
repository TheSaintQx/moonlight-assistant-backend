'use strict';
const assert = require('node:assert/strict');
const core = require('../moon-vision-core.js');
const t = core.__test;

const quick = {
  skillTrack: true,
  status: 'processing_deep',
  quick: { text: 'quick answer' },
  skillDeliveredStages: []
};
assert.deepEqual(t.skillDeliveryInfo(quick), {
  tracked: true, stage: 'quick', delivered: false
});
quick.skillDeliveredStages.push('quick');
assert.deepEqual(t.skillDeliveryInfo(quick), {
  tracked: true, stage: 'quick', delivered: true
});
const deep = {
  skillTrack: true,
  status: 'deep_ready',
  quick: { text: 'quick answer' },
  text: 'deep answer',
  skillDeliveredStages: ['quick']
};
assert.deepEqual(t.skillDeliveryInfo(deep), {
  tracked: true, stage: 'deep', delivered: false
});
deep.skillDeliveredStages.push('deep');
assert.deepEqual(t.skillDeliveryInfo(deep), {
  tracked: true, stage: 'deep', delivered: true
});

// Concurrent worker/ack writes must merge delivery markers monotonically.
const now = Date.now();
const merged = t.mergeState({ answers: { '1': {
  status: 'deep_ready', createdAt: 100, doneAt: 200, doneAtMs: 200000,
  skillTrack: true, skillDeliveredStages: ['quick']
} } }, { answers: { '1': {
  status: 'deep_ready', createdAt: 100, doneAt: 200, doneAtMs: 200000,
  skillTrack: true, skillDeliveredStages: ['deep']
} } }, now);
assert.deepEqual(merged.answers['1'].skillDeliveredStages.sort(), ['deep', 'quick']);
assert.equal(merged.answers['1'].skillTrack, true);

// Historic records must not be exposed to recovery by the new Skill protocol.
assert.deepEqual(t.skillDeliveryInfo({ status: 'deep_ready', text: 'legacy' }), {
  tracked: false, stage: 'deep', delivered: false
});

console.log('PASS skill-delivery-smoke: tracked stages, independent quick/deep acknowledgement, CAS marker merge, legacy isolation');
