'use strict';

const assert = require('node:assert/strict');

process.env.KB_URL = 'https://ke.test/function';
process.env.KB_TOKEN = 'test-kb-token';
process.env.YC_API_KEY = 'test-yc-key';
process.env.MODEL_URI = 'gpt://test-folder/qwen/latest';

const core = require('../moon-vision-core.js').__test;

function abortableDelay(ms, signal) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(resolve, ms);
    if (!signal) return;
    if (signal.aborted) {
      clearTimeout(timer);
      const error = new Error('aborted');
      error.name = 'TimeoutError';
      reject(error);
      return;
    }
    signal.addEventListener('abort', () => {
      clearTimeout(timer);
      const error = new Error('aborted');
      error.name = 'TimeoutError';
      reject(error);
    }, { once: true });
  });
}

(async () => {
  const oldFetch = global.fetch;
  const calls = [];
  global.fetch = async (url, options) => {
    const target = String(url);
    const body = JSON.parse(options.body);
    calls.push({ target, body });

    if (target === process.env.KB_URL) {
      assert.equal(body.action, 'search');
      await abortableDelay(2300, options.signal);
      return {
        ok: true,
        status: 200,
        json: async () => ({
          status: 'ok',
          game: 'Cyberpunk 2077',
          intent: { name: 'general', section: '' },
          results: [{
            title: 'Пасифика',
            evidence: 'Пасифика — район Найт-Сити, расположенный на юге города.'
          }]
        })
      };
    }

    if (target.includes('/v1/chat/completions')) {
      return {
        status: 200,
        text: async () => JSON.stringify({
          choices: [{
            message: { content: JSON.stringify({
              speech: 'Пасифика — район Найт-Сити на юге города.',
              unk: false,
              conf: 0.9,
              clarify: null,
              marker: null
            }) },
            finish_reason: 'stop'
          }],
          usage: { prompt_tokens: 180, completion_tokens: 26 }
        })
      };
    }
    throw new Error('unexpected URL: ' + target);
  };

  try {
    const started = Date.now();
    const result = await core.kbAnswer(
      'Cyberpunk 2077',
      'Где находится Пасифика?',
      'Где находится Пасифика?',
      { fast: true, maxTokens: 220, deadline: Date.now() + 8500 }
    );
    const elapsed = Date.now() - started;
    assert.equal(result.status, 'ok');
    assert.equal(result.out.src, 'kb');
    assert.match(result.out.text, /Пасифика/);
    assert.ok(elapsed >= 2200, 'delayed KE response must actually be awaited');
    assert.ok(elapsed < 5000, 'quick path should complete within its bounded local smoke budget');
    assert.equal(calls[0].body.fast, true);
  } finally {
    global.fetch = oldFetch;
  }

  // Offline warm must use KE's dedicated action, not the old live-Wiki warm.
  const warmCalls = [];
  global.fetch = async (url, options) => {
    const body = JSON.parse(options.body);
    warmCalls.push(body);
    return {
      ok: true,
      status: 200,
      json: async () => ({
        status: 'ready', gameId: 'ведьмак-3', version: '1.0.0',
        kitGameId: 'witcher_3', pages: 13258, language: 'ru',
        source: 'Ведьмак Вики (RU)', archiveSha256: 'a'.repeat(64)
      })
    };
  };
  try {
    const warm = await core.warmKnowledge('Ведьмак 3', false);
    assert.equal(warm.status, 'ok');
    assert.equal(warm.pages, 13258);
    assert.equal(warm.offline, true);
    assert.equal(warmCalls.length, 1);
    assert.equal(warmCalls[0].action, 'offlineWarm');
  } finally {
    global.fetch = oldFetch;
  }

  // A completed Quick miss can be dispatched as a separate Deep invocation,
  // and a lost dispatch can be recovered after the cooldown.
  const now = Math.floor(Date.now() / 1000);
  const pendingMiss = { status: 'pending', fastDone: true };
  assert.equal(core.canKickDeep(pendingMiss, now), true);
  assert.equal(core.shouldKickDeepRecovery(pendingMiss, false, now), true);
  assert.equal(core.shouldKickDeepRecovery(
    Object.assign({}, pendingMiss, { deepKickedAt: now - 2 }), false, now
  ), false);

  process.stdout.write('quick-path-smoke: delayed KE, offline warm, and Deep dispatch recovery passed\n');
})().catch(error => {
  console.error(error);
  process.exitCode = 1;
});
