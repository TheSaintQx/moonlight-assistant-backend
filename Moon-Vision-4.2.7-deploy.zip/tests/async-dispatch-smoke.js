'use strict';

const assert = require('node:assert/strict');

process.env.AUTH_TOKEN = 'test-moon-token';
process.env.KB_URL = 'https://ke.test/function';
process.env.KB_TOKEN = 'test-kb-token';
process.env.YC_API_KEY = 'test-yc-key';
process.env.MODEL_URI = 'gpt://test-folder/qwen/latest';
process.env.ACCESS_KEY_ID = 'test-access';
process.env.SECRET_ACCESS_KEY = 'test-secret';
process.env.BUCKET = 'moon-assistant';
process.env.SELF_URL = 'https://vision.test/function';

const core = require('../moon-vision-core.js');

(async () => {
  const oldFetch = global.fetch;
  let stateBytes = null;
  let etagCounter = 0;
  const deepDispatches = [];
  const warmDispatches = [];
  const keActions = [];

  global.fetch = async (url, options = {}) => {
    const target = new URL(String(url));

    if (target.hostname === 'storage.yandexcloud.net') {
      const key = target.pathname.split('/').slice(2).join('/');
      if (options.method === 'GET') {
        if (key === 'state.json' && stateBytes) {
          return new Response(stateBytes, {
            status: 200,
            headers: { etag: '"state-' + etagCounter + '"' }
          });
        }
        return new Response('', { status: 404 });
      }
      if (options.method === 'PUT') {
        const bytes = options.body == null
          ? Buffer.alloc(0)
          : Buffer.from(options.body);
        if (key === 'state.json') {
          stateBytes = Buffer.from(bytes);
          etagCounter++;
        }
        return new Response('', {
          status: 200,
          headers: { etag: '"state-' + etagCounter + '"' }
        });
      }
      return new Response('', { status: 200 });
    }

    if (target.href.startsWith(process.env.KB_URL)) {
      const body = JSON.parse(options.body);
      keActions.push(body.action);
      assert.equal(body.action, 'search');
      return new Response(JSON.stringify({
        status: 'no_evidence',
        game: 'Cyberpunk 2077',
        results: []
      }), {
        status: 200,
        headers: { 'content-type': 'application/json' }
      });
    }

    if (target.hostname === 'vision.test') {
      if (target.searchParams.get('warm') === '1') {
        warmDispatches.push(target.searchParams.get('game'));
        return new Response('', { status: 200 });
      }
      if (target.searchParams.get('integration') === 'async') {
        const body = JSON.parse(options.body);
        if (body.action === 'deep') deepDispatches.push(body);
        return new Response('', { status: 202 });
      }
    }

    throw new Error('unexpected URL: ' + target.href);
  };

  try {
    const response = await core.handler({
      httpMethod: 'POST',
      headers: { 'X-Moon-Token': process.env.AUTH_TOKEN },
      queryStringParameters: {},
      body: JSON.stringify({
        q: 'Кто такой незнакомый персонаж?',
        game: 'Cyberpunk 2077',
        cid: 'c-' + 'a'.repeat(24),
        skillTrack: true
      }),
      isBase64Encoded: false
    });

    const body = JSON.parse(response.body);
    assert.equal(response.statusCode, 200);
    assert.equal(body.status, 'query');
    assert.equal(body.stage, 'deep');
    assert.ok(body.qid > 0);
    assert.equal(keActions.length, 1);
    assert.equal(keActions[0], 'search');
    assert.equal(deepDispatches.length, 1, 'Deep must be launched separately after a Quick miss');
    assert.equal(deepDispatches[0].action, 'deep');
    assert.ok(deepDispatches[0].cid);
    assert.equal(warmDispatches.length, 1, 'selected game should schedule offline prewarm');
    assert.equal(warmDispatches[0], 'Cyberpunk 2077');
    const persisted = JSON.parse(stateBytes.toString('utf8'));
    const saved = Object.values(persisted.answers || {})[0];
    assert.equal(saved && saved.skillTrack, true, 'new skill asks must be tagged for safe recovery');
    assert.deepEqual(saved && saved.skillDeliveredStages, []);

    process.stdout.write('async-dispatch-smoke: Quick miss returns query and launches separate Deep invocation\n');
  } finally {
    global.fetch = oldFetch;
  }
})().catch(error => {
  console.error(error);
  process.exitCode = 1;
});
