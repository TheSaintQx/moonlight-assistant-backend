'use strict';

const assert = require('node:assert/strict');

process.env.KB_URL = 'https://ke.test/function';
process.env.KB_TOKEN = 'test-kb-token';
process.env.YC_API_KEY = 'test-yc-key';
process.env.MODEL_URI = 'gpt://test-folder/qwen/latest';

const core = require('../moon-vision-core.js').__test;

const researchPayload = {
  status: 'ok',
  gameId: 'witcher_3',
  game: 'Ведьмак 3',
  query: 'Сколько лет Геральту?',
  intent: { type: 'attribute', entity: ['Геральт'], asksLocation: false },
  primary: { title: 'Геральт из Ривии' },
  sufficient: true,
  missing: [],
  facts: [
    { kind: 'birth_date', text: 'Геральт родился в 1167 году.', source: 'Геральт из Ривии', section: 'Биография' },
    { kind: 'age', text: 'В третьей игре Весемир говорит, что Геральту около ста лет.', source: 'Геральт из Ривии', section: 'Возраст' }
  ],
  list: null,
  rounds: [{ round: 1, sufficient: true, missing: [] }],
  results: [{ title: 'Геральт из Ривии', evidence: 'Геральт родился в 1167 году. В третьей игре Весемир говорит, что Геральту около ста лет.' }],
  search: { mode: 'offline-kit-research', offlineFirst: true, onlineFallbackUsed: false }
};

const normalized = core.normalizeKbResearchResults(researchPayload, 'Сколько лет Геральту?');
assert.equal(normalized.status, 'ok');
assert.equal(normalized.game, 'Ведьмак 3');
assert.equal(normalized.research.sufficient, true);
assert.deepEqual(normalized.research.missing, []);
assert.equal(normalized.research.facts[0].kind, 'birth_date');
assert.equal(normalized.research.facts[1].kind, 'age');
assert.equal(normalized.research.mode, 'offline-kit-research');
assert.equal(normalized.results[0].title, 'Геральт из Ривии');

const partialPayload = Object.assign({}, researchPayload, {
  sufficient: false,
  missing: ['в источнике не указан точный возраст'],
  facts: [{ kind: 'birth_date', text: 'Геральт родился в 1167 году.' }],
  list: { total: 11, expected: 14, completeness: 11 / 14, truncated: true }
});
const partial = core.normalizeKbResearchResults(partialPayload, 'Сколько лет Геральту?');
assert.equal(partial.research.sufficient, false);
assert.equal(partial.research.missing.length, 1);
assert.equal(partial.research.facts[0].kind, 'birth_date');
assert.ok(Math.abs(partial.research.list.completeness - (11 / 14)) < 0.00001);
assert.equal(partial.research.list.truncated, true);

(async () => {
  const calls = [];
  const oldFetch = global.fetch;
  global.fetch = async (url, options) => {
    const body = JSON.parse(options.body);
    calls.push({ url: String(url), body });

    if (String(url) === process.env.KB_URL) {
      if (body.action === 'research') {
        return {
          ok: true,
          status: 200,
          json: async () => researchPayload
        };
      }
      if (body.action === 'search') {
        return {
          ok: true,
          status: 200,
          json: async () => ({
            status: 'ok', game: 'Ведьмак 3',
            intent: { type: 'attribute', entity: ['Геральт'] },
            results: [{ title: 'Геральт из Ривии', evidence: 'Геральт — ведьмак из Школы Волка.' }]
          })
        };
      }
      throw new Error('unexpected KE action ' + body.action);
    }

    if (String(url) === 'https://ai.api.cloud.yandex.net/v1/chat/completions') {
      const content = JSON.stringify({
        speech: 'Wiki сообщает, что Геральту около ста лет; год рождения сам по себе возраст не определяет.',
        unk: false,
        conf: 0.82,
        clarify: null,
        marker: null
      });
      return {
        status: 200,
        text: async () => JSON.stringify({
          choices: [{ message: { content }, finish_reason: 'stop' }],
          usage: { prompt_tokens: 200, completion_tokens: 40 }
        })
      };
    }

    throw new Error('unexpected URL ' + url);
  };

  try {
    const deep = await core.kbAnswer('Ведьмак 3', 'Сколько лет Геральту?', 'Сколько лет Геральту?', {
      deep: true,
      research: true,
      rounds: 2,
      maxTokens: 2048,
      deadline: Date.now() + 60000
    });
    assert.equal(deep.status, 'ok');
    assert.equal(deep.out.src, 'kb');
    assert.equal(deep.diag.kbMode, 'research');
    assert.equal(deep.diag.researchSufficient, true);
    const researchCall = calls.find(call => call.url === process.env.KB_URL && call.body.action === 'research');
    assert.ok(researchCall, 'deep phase must call KE action=research');
    assert.equal(researchCall.body.rounds, 2);
    const aiCall = calls.find(call => call.url.includes('chat/completions'));
    assert.ok(aiCall, 'deep phase must call Qwen');
    assert.match(aiCall.body.messages[0].content, /универсальный игровой аналитик/);
    assert.match(aiCall.body.messages[1].content, /"kind":"birth_date"/);
    assert.match(aiCall.body.messages[1].content, /"kind":"age"/);
    assert.match(aiCall.body.messages[1].content, /sufficient/);

    calls.length = 0;
    const fast = await core.kbAnswer('Ведьмак 3', 'Кто такой Геральт?', 'Кто такой Геральт?', {
      fast: true,
      maxTokens: 220,
      deadline: Date.now() + 10000
    });
    assert.equal(fast.status, 'ok');
    assert.equal(fast.diag.kbMode, 'search');
    assert.ok(calls.some(call => call.url === process.env.KB_URL && call.body.action === 'search'),
      'fast phase must keep using KE action=search');
    assert.ok(!calls.some(call => call.url === process.env.KB_URL && call.body.action === 'research'),
      'fast phase must not call research');
  } finally {
    global.fetch = oldFetch;
  }

  process.stdout.write('vision research integration smoke: deep research + quick search passed\n');
})().catch(error => {
  console.error(error);
  process.exitCode = 1;
});
