'use strict';
const assert = require('node:assert/strict');
process.env.MOON_TOKEN = 'test-moon-token';
const skill = require('../index.js');
const { handler, _test } = skill;
const originalFetch = global.fetch;

function jsonResponse(body, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { 'content-type': 'application/json' }
  });
}

function event(text, state) {
  return {
    session: {
      message_id: 101,
      session_id: 'smoke-session',
      new: false,
      user: { user_id: 'smoke-user-id' }
    },
    request: { command: text.toLowerCase(), original_utterance: text },
    ...(state ? { state } : {})
  };
}

async function run() {
  assert.equal(_test.version, '9.6-a-v3.5.1');
  assert.equal(_test.recoveryTimeoutMs, 1400);
  assert.equal(_test.isGameInfo('Какая сейчас выбрана игра?'), true);

  // Recovery after Alice omits state: an undelivered, tracked answer is returned once.
  let calls = [];
  global.fetch = async (url, init = {}) => {
    const u = new URL(String(url));
    calls.push({ url: u, method: init.method || 'GET' });
    if (u.searchParams.get('skillprogress') === '1') {
      return jsonResponse({
        status: 'done', qid: 77, cid: 'c-new-pending',
        stage: 'deep', final: true,
        text: 'ВОССТАНОВЛЕННЫЙ ОТВЕТ', src: 'kb', unk: false, game: 'ведьмак 3'
      });
    }
    if (u.searchParams.get('skillack') === '1') {
      assert.equal(u.searchParams.get('cid'), 'c-new-pending');
      assert.equal(u.searchParams.get('stage'), 'deep');
      return jsonResponse({ status: 'ok', stage: 'deep' });
    }
    throw new Error('Unexpected request: ' + u.href);
  };
  const recovered = await handler(event('Ну что там'));
  assert.match(recovered.response.text, /ВОССТАНОВЛЕННЫЙ ОТВЕТ/);
  assert.equal(recovered.analytics.events[0].value.route, 'followup-recovered-done');
  assert.equal(recovered.analytics.events[0].value.has_game, true);
  assert.equal(recovered.session_state.game, 'ведьмак 3');
  assert.equal(calls.filter(c => c.url.searchParams.get('skillprogress') === '1').length, 1);
  assert.equal(calls.filter(c => c.url.searchParams.get('skillack') === '1').length, 1);

  // After a stage was acknowledged, a repeated follow-up must not replay it.
  calls = [];
  global.fetch = async (url, init = {}) => {
    const u = new URL(String(url));
    calls.push(u);
    if (u.searchParams.get('skillprogress') === '1') {
      return jsonResponse({ status: 'none', delivered: true, tracked: true, game: 'ведьмак 3' });
    }
    throw new Error('A delivered result must not be fetched again: ' + u.href);
  };
  const repeated = await handler(event('Ну что там'));
  assert.equal(repeated.analytics.events[0].value.route, 'followup-none');
  assert.equal(repeated.analytics.events[0].value.has_game, true);
  assert.equal(repeated.session_state.game, 'ведьмак 3');
  assert.match(repeated.response.text, /нет ожидающего ответа/i);
  assert.equal(calls.length, 1);

  // A delivered Quick stage is not replayed while Deep is still running.
  calls = [];
  global.fetch = async (url, init = {}) => {
    const u = new URL(String(url));
    calls.push(u);
    if (u.searchParams.get('skillprogress') === '1') {
      return jsonResponse({ status: 'deep_pending', qid: 77,
        cid: 'c-quick-delivered', stage: 'quick', deep_pending: true, delivered: true, game: 'ведьмак 3' });
    }
    throw new Error('Quick stage must not be fetched again: ' + u.href);
  };
  const deepWaiting = await handler(event('Ну что там'));
  assert.equal(deepWaiting.analytics.events[0].value.route, 'followup-deep-pending');
  assert.match(deepWaiting.response.text, /подробный разбор ещё собирается/i);
  assert.equal(calls.length, 1);

  // If server progress says the job is still active, recover its CID and poll it.
  calls = [];
  global.fetch = async (url, init = {}) => {
    const u = new URL(String(url));
    calls.push(u);
    if (u.searchParams.get('skillprogress') === '1') {
      return jsonResponse({
        status: 'processing_fast', qid: 78, cid: 'c-active-recovered',
        skill_tracked: true, skill_delivered: false, game: 'ведьмак 3'
      });
    }
    if (u.searchParams.get('answer') === '1') {
      assert.equal(u.searchParams.get('cid'), 'c-active-recovered');
      return jsonResponse({
        status: 'done', qid: 78, cid: 'c-active-recovered',
        stage: 'deep', text: 'АКТИВНАЯ ЗАДАЧА ВОССТАНОВЛЕНА', src: 'kb', unk: false
      });
    }
    if (u.searchParams.get('skillack') === '1') {
      return jsonResponse({ status: 'ok', stage: 'deep' });
    }
    throw new Error('Unexpected request: ' + u.href);
  };
  const active = await handler(event('Ну что там'));
  assert.match(active.response.text, /АКТИВНАЯ ЗАДАЧА ВОССТАНОВЛЕНА/);
  assert.equal(active.analytics.events[0].value.route, 'followup-done');
  assert.equal(calls.filter(u => u.searchParams.get('answer') === '1').length, 1);
  assert.equal(calls.filter(u => u.searchParams.get('skillack') === '1').length, 1);

  // Ordinary questions still restore the selected game and tag new requests for recovery.
  calls = [];
  let askPayload = null;
  global.fetch = async (url, init = {}) => {
    const u = new URL(String(url));
    calls.push(u);
    if (u.searchParams.get('usergame') === '1') return jsonResponse({ game: 'ведьмак 3' });
    if (u.searchParams.get('integration') === 'async') {
      askPayload = JSON.parse(init.body);
      return jsonResponse({ accepted: true }, 202);
    }
    if (u.searchParams.get('answer') === '1') {
      return jsonResponse({
        status: 'done', qid: 79, cid: askPayload.cid,
        text: 'Геральт — ведьмак Школы Волка.', src: 'kb', stage: 'deep', unk: false
      });
    }
    if (u.searchParams.get('skillack') === '1') return jsonResponse({ status: 'ok' });
    throw new Error('Unexpected request: ' + u.href);
  };
  const asked = await handler(event('Кто такой Геральт?'));
  assert.equal(askPayload && askPayload.game, 'ведьмак 3');
  assert.equal(askPayload && askPayload.skillTrack, true);
  assert.equal(asked.analytics.events[0].value.has_game, true);
  assert.equal(asked.analytics.events[0].value.route, 'async-poll-done');

  console.log('PASS 3.5.1 smoke: pending recovery without Alice state; one-time delivery; active CID polling; tracked ask');
}

run().catch(err => {
  console.error(err);
  process.exitCode = 1;
}).finally(() => {
  global.fetch = originalFetch;
});
