'use strict';

const assert = require('node:assert/strict');
const { buildResearch } = require('../lib/research.js');

function sourceFor(title, sections, relatedTitles) {
  const page = {
    id: 1,
    title,
    url: 'https://example.test/wiki/' + encodeURIComponent(title),
    categories: ['Тест'],
    sections,
    text: sections.map(section => section.text).join('\n'),
    length: sections.reduce((n, section) => n + section.text.length, 0),
  };
  return {
    meta: { gameId: 'test-game', game: 'Тестовая игра', language: 'ru', siteName: 'Тестовая Wiki' },
    listTitles: () => relatedTitles || [{ id: 1, title }],
    getPage: id => Number(id) === 1 ? page : null,
    search: () => ({ results: [{ pageId: 1, title, url: page.url, score: 100 }] }),
  };
}

(async () => {
  const armorSets = sourceFor('Броня (Тестовая RPG)', [
    { h: '', text: 'В статье перечислены доступные комплекты брони для персонажа.' },
    { h: 'Комплект Школы Волка', text: 'Базовое снаряжение. Доспех Школы Волка. Перчатки Школы Волка.' },
    { h: 'Комплект Школы Кота', text: 'Базовое снаряжение. Доспех Школы Кота. Перчатки Школы Кота.' },
    { h: 'Комплект Школа Медведя', text: 'Базовое снаряжение. Доспех Школы Медведя. Перчатки Школы Медведя.' },
    { h: 'Забытый комплект Школы Волка', text: 'Дополнительный вариант снаряжения Школы Волка.' },
    { h: 'Темерский комплект', text: 'Обычный комплект без привязки к школе.' },
  ]);
  const setResult = await buildResearch(armorSets, {
    query: 'Какие ведьмачьи комплекты брони можно собрать в Тестовой RPG?',
    rounds: 2,
  });
  assert.equal(setResult.intent.type, 'list');
  assert.equal(setResult.list.total, 3, 'school-set headings should become list items, with duplicate variants collapsed');
  assert.deepEqual(setResult.list.items.map(item => item.text), [
    'Школа Волка', 'Школа Кота', 'Школа Медведя',
  ]);
  assert.equal(setResult.sufficient, true, 'three structurally identified school sets are sufficient for a list answer');
  assert.ok(setResult.sources.some(item => item.section === 'Комплект Школы Кота'));
  assert.ok(setResult.list.items.every(item => item.section), 'list entries retain the section that supports them');
  assert.ok(!setResult.followUpQueries.some(item => /биограф/u.test(item)), 'list research must not ask for biographies');

  const armorTypes = await buildResearch(armorSets, {
    query: 'Какие типы брони существуют в Тестовой RPG?',
    rounds: 1,
  });
  assert.equal(armorTypes.list.total, 0, 'armor-type questions must not be answered with school-set headings');

  const ageSource = sourceFor('Геральт из Ривии', [
    { h: '', text: 'Геральт из Ривии — ведьмак и главный герой истории. Он известен как Белый Волк.' },
    { h: 'Биография', text: 'Он родился в 1167 году согласно настольной игре. Весемир говорит, что Геральту около ста лет.' },
  ]);
  const age = await buildResearch(ageSource, { query: 'Сколько лет Геральту?', rounds: 1 });
  assert.equal(age.status, 'ok');
  assert.equal(age.sufficient, true);
  assert.equal(age.primary.title, 'Геральт из Ривии');
  assert.ok(age.facts.some(item => item.kind === 'birth_date' && /родился в 1167/u.test(item.text)));
  assert.ok(age.facts.some(item => item.kind === 'age' && /около ста лет/u.test(item.text)));

  const birthOnly = sourceFor('Геральт из Ривии', [
    { h: '', text: 'Геральт из Ривии — ведьмак. Он родился в 1167 году согласно настольной игре.' },
  ]);
  const birth = await buildResearch(birthOnly, { query: 'Сколько лет Геральту?', rounds: 1 });
  assert.equal(birth.sufficient, false, 'birth year alone is not an explicit age');
  assert.equal(birth.facts.length, 1);
  assert.equal(birth.facts[0].kind, 'birth_date');
  assert.ok(birth.missing.some(item => item.includes('без подтверждённого года событий')));

  const debutOnly = sourceFor('Геральт из Ривии', [
    { h: '', text: 'Геральт из Ривии — ведьмак. Персонаж впервые появился в игре 2015 года. Возраст обсуждался после релиза.' },
  ]);
  const noAge = await buildResearch(debutOnly, { query: 'Сколько лет Геральту?', rounds: 1 });
  assert.equal(noAge.sufficient, false);
  assert.equal(noAge.facts.length, 0);
  assert.ok(noAge.missing.some(item => item.includes('нет подтверждённого значения возраста')));

  const directCases = [
    'Ему 42 года.',
    'Возраст персонажа составляет около 42 лет.',
    'Геральту примерно 42 года.',
    'Он — 42-летний ведьмак.',
    'The character is 42 years old.',
  ];
  for (const sentence of directCases) {
    const direct = sourceFor('Геральт из Ривии', [{ h: '', text: 'Геральт из Ривии — ведьмак. ' + sentence }]);
    const result = await buildResearch(direct, { query: 'Сколько лет Геральту?', rounds: 1 });
    assert.equal(result.sufficient, true, 'explicit age should count: ' + sentence);
    assert.ok(result.facts.some(item => item.kind === 'age'), 'age fact missing: ' + sentence);
  }

  const englishBirthOnly = sourceFor('Geralt of Rivia', [
    { h: '', text: 'Geralt of Rivia is a witcher. He was born in 1167.' },
  ]);
  const englishBirth = await buildResearch(englishBirthOnly, { query: 'How old is Geralt of Rivia?', rounds: 1 });
  assert.equal(englishBirth.sufficient, false);
  assert.ok(englishBirth.facts.some(item => item.kind === 'birth_date'));

  console.log('research-smoke: age + structural-list evidence checks passed');
})().catch(error => {
  console.error(error);
  process.exitCode = 1;
});
