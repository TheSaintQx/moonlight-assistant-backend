'use strict';

const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');

const fixtureRoot = path.join(__dirname, 'fixtures/test_offline_kit');
const pointer = JSON.parse(fs.readFileSync(path.join(fixtureRoot, 'pointer.json'), 'utf8'));
const bundle = fs.readFileSync(path.join(fixtureRoot, 'bundle.tar.gz'));
const wikiText = [
  'Геральт из Ривии — ведьмак и главный герой серии игр.',
  '',
  'Биография',
  'Он родился в 1167 году согласно настольной игре.',
  'В третьей части Весемир говорит, что Геральту около ста лет.',
].join('\n');
const rawPage = {
  pageid: 123,
  title: 'Геральт из Ривии',
  fullurl: 'https://example.test/wiki/Geralt',
  extract: wikiText,
};
const apiManifest = {
  game: 'Тестовая игра',
  source: {
    api: 'https://test.fandom.com/api.php',
    language: 'ru',
    siteName: 'Тестовая Wiki',
  },
};

let s3Calls = 0;
let wikiCalls = 0;
function response(status, body) {
  const bytes = Buffer.isBuffer(body) ? body : Buffer.from(typeof body === 'string' ? body : JSON.stringify(body));
  return {
    ok: status >= 200 && status < 300,
    status,
    headers: { get: name => name.toLowerCase() === 'etag' ? '"test-etag"' : null },
    arrayBuffer: async () => Uint8Array.from(bytes).buffer,
    json: async () => JSON.parse(bytes.toString('utf8')),
  };
}

(async () => {
  process.env.KB_TOKEN = 'test-token-only';
  process.env.ACCESS_KEY_ID = 'test-access-key';
  process.env.SECRET_ACCESS_KEY = 'test-secret-key';
  process.env.KB_BUCKET = 'moon-assistant';

  global.fetch = async (url, options) => {
    const parsed = new URL(String(url));
    if (parsed.hostname === 'storage.yandexcloud.net') {
      s3Calls++;
      const key = decodeURIComponent(parsed.pathname.replace(/^\/moon-assistant\/kb\//, ''));
      if (key === 'games/test-game/wiki/active.json') return response(200, pointer);
      if (key === 'games/test-game/wiki/versions/1.0.0/kit.tar.gz') return response(200, bundle);
      if (key === 'games/live-game/wiki/active.json') return response(404, '');
      if (key === 'games/live-game/manifest.json') return response(200, apiManifest);
      return response(404, '');
    }
    if (parsed.hostname.endsWith('.fandom.com')) {
      wikiCalls++;
      const params = parsed.searchParams;
      if (params.get('list') === 'search') {
        return response(200, { query: { search: [{ title: rawPage.title }] } });
      }
      return response(200, { query: { pages: [rawPage] } });
    }
    throw new Error('Unexpected fetch URL: ' + parsed.hostname);
  };

  const { handler } = require('../index.js');
  const invoke = async game => {
    const result = await handler({
      httpMethod: 'POST',
      headers: { 'x-kb-token': 'test-token-only' },
      body: JSON.stringify({ action: 'research', game, query: 'Сколько лет Геральту?', rounds: 1 }),
    });
    assert.equal(result.statusCode, 200);
    return JSON.parse(result.body);
  };

  const offlineResult = await invoke('Test Game');
  assert.equal(offlineResult.status, 'ok');
  assert.equal(offlineResult.search.mode, 'offline-kit-research');
  assert.equal(offlineResult.search.onlineFallbackUsed, false);
  assert.ok(offlineResult.facts.some(item => item.kind === 'age'));
  assert.equal(wikiCalls, 0, 'sufficient offline results must not call live Wiki');

  const liveResult = await invoke('Live Game');
  assert.equal(liveResult.status, 'ok');
  assert.equal(liveResult.search.mode, 'live-wiki-research');
  assert.equal(liveResult.search.onlineFallbackUsed, true);
  assert.ok(liveResult.facts.some(item => item.kind === 'age'));
  assert.ok(wikiCalls > 0, 'live fallback should call MediaWiki');
  assert.ok(s3Calls >= 4, 'mock Object Storage should be exercised');

  console.log('handler-research-smoke: HTTP route + offline-first + live fallback passed');
})().catch(error => {
  console.error(error);
  process.exitCode = 1;
});
