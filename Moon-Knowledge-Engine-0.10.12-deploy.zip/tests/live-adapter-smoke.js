'use strict';

const assert = require('node:assert/strict');
const { researchGame } = require('../lib/ke-research-live.js');

(async () => {
  const wikiText = [
    'Геральт из Ривии — ведьмак и главный герой серии игр.',
    '',
    'Биография',
    'В настольной игре указан год рождения Геральта — 1167.',
    'В третьей части Весемир говорит, что Геральту около ста лет.',
  ].join('\n');
  const rawPage = {
    pageid: 123,
    title: 'Геральт из Ривии',
    fullurl: 'https://example.test/wiki/Geralt',
    extract: wikiText,
  };
  let requests = 0;
  const result = await researchGame(
    { game: 'Ведьмак 3', query: 'Сколько лет Геральту?', rounds: 1 },
    {
      slug: value => String(value).toLowerCase().replace(/\s+/g, '-'),
      normalize: value => String(value).toLowerCase().replace(/[^\p{L}\p{N}]+/gu, ' ').trim(),
      maxQuery: 300,
      manifestKey: id => 'games/' + id + '/manifest.json',
      readJson: async () => ({
        game: 'Ведьмак 3',
        source: {
          api: 'https://example.test/api.php',
          language: 'ru',
          siteName: 'Тестовая Wiki',
        },
      }),
      wikiGet: async (api, params) => {
        requests++;
        if (params.list === 'search') {
          return { query: { search: [{ title: rawPage.title }] } };
        }
        return { query: { pages: [rawPage] } };
      },
      wikiPages: data => data && data.query ? data.query.pages || [] : [],
      makePageRecord: raw => ({
        pageId: raw.pageid,
        title: raw.title,
        url: raw.fullurl,
        categories: [],
        extract: raw.extract,
      }),
      splitSections: text => {
        const lines = String(text).split('\n');
        const sections = [];
        let heading = '';
        let body = [];
        const flush = () => {
          if (body.length) sections.push({ heading, text: body.join('\n'), service: false });
          body = [];
        };
        for (const line of lines) {
          if (line === 'Биография') {
            flush();
            heading = line;
          } else body.push(line);
        }
        flush();
        return sections;
      },
    }
  );

  assert.equal(result.status, 'ok');
  assert.equal(result.sufficient, true);
  assert.equal(result.search.mode, 'live-wiki');
  assert.ok(result.facts.some(item => item.kind === 'age'));
  assert.ok(result.facts.some(item => item.kind === 'birth_date'));
  assert.ok(requests <= 10, 'MediaWiki request budget should not exceed 10');
  console.log('live-adapter-smoke: research + request budget passed (' + requests + ' calls)');
})().catch(error => {
  console.error(error);
  process.exitCode = 1;
});
