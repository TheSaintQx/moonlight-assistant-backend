'use strict';

const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { createOfflineWikiBridge, _internal } = require('../offline-wiki-bridge.js');
const { buildResearch } = require('../lib/research.js');

(async () => {
  const fixtureRoot = path.resolve(__dirname, 'fixtures/test_offline_kit');
  const pointer = JSON.parse(fs.readFileSync(path.join(fixtureRoot, 'pointer.json'), 'utf8'));
  const bundle = fs.readFileSync(path.join(fixtureRoot, 'bundle.tar.gz'));
  assert.equal(_internal.sha256(bundle), pointer.sha256, 'fixture bundle SHA256');

  const cacheRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'moon-offline-research-'));
  try {
    const bridge = createOfflineWikiBridge({
      cacheRoot,
      getActivePointer: async gameId => gameId === pointer.gameId ? pointer : null,
      getBundle: async key => {
        assert.equal(key, 'games/test-game/wiki/versions/1.0.0/kit.tar.gz');
        return bundle;
      },
    });

    const status = await bridge.prepare(pointer.gameId);
    assert.equal(status.status, 'ready');
    assert.equal(status.pages, 1);
    assert.equal(status.kitGameId, 'test_game');

    const result = await bridge.research(
      { gameId: pointer.gameId, query: 'Сколько лет Геральту?' },
      source => buildResearch(source, { query: 'Сколько лет Геральту?', rounds: 1 })
    );
    assert.equal(result.status, 'ok');
    assert.equal(result.sufficient, true);
    assert.equal(result.search.mode, 'offline-kit-research');
    assert.equal(result.offline.status, 'ready');
    assert.ok(result.facts.some(item => item.kind === 'age'));

    console.log('offline-bridge-smoke: prepare + research passed');
  } finally {
    fs.rmSync(cacheRoot, { recursive: true, force: true });
  }
})().catch(error => {
  console.error(error);
  process.exitCode = 1;
});
