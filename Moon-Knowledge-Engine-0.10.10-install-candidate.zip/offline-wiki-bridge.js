'use strict';

// Offline Wiki bridge for Moon Knowledge Engine.
// Game-specific kit data remains in Object Storage, not in the function package.

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const zlib = require('zlib');
const { createOfflineWiki } = require('./offline-wiki');

const ACTIVE_CACHE_TTL_MS = 15000;
const MAX_ENGINE_CACHE = 1;
const DEFAULT_CACHE_ROOT = '/tmp/moon-offline-wiki';
const MAX_UNPACKED_BYTES = 400 * 1024 * 1024;
const VERSION_RE = /^[A-Za-z0-9._-]{1,80}$/;
const SHA256_RE = /^[a-f0-9]{64}$/i;

function normalizeGameId(value) {
  return String(value == null ? '' : value)
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '_')
    .replace(/^_+|_+$/g, '');
}

function textField(buffer, start, length) {
  return buffer.subarray(start, start + length).toString('utf8').replace(/\0.*$/s, '').trim();
}

function octalField(buffer, start, length) {
  const value = textField(buffer, start, length);
  if (!value) return 0;
  const parsed = Number.parseInt(value, 8);
  if (!Number.isSafeInteger(parsed) || parsed < 0) {
    throw new Error('invalid tar numeric field');
  }
  return parsed;
}

function safeTarget(root, relativeName) {
  const normalized = path.posix.normalize(String(relativeName || '').replace(/\\/g, '/'));
  if (!normalized || normalized === '.' || normalized.startsWith('/') ||
      normalized === '..' || normalized.startsWith('../')) {
    throw new Error('unsafe path in offline Wiki package');
  }
  const base = path.resolve(root);
  const target = path.resolve(base, ...normalized.split('/'));
  if (target !== base && !target.startsWith(base + path.sep)) {
    throw new Error('offline Wiki package path escapes target directory');
  }
  return target;
}

// Minimal USTAR reader: accepts regular files/directories only. The pack builder
// emits USTAR paths; links and special files are deliberately rejected.
function extractTarGz(buffer, destination) {
  if (!Buffer.isBuffer(buffer) || buffer.length < 18) {
    throw new Error('offline Wiki package is empty or invalid');
  }
  const tar = zlib.gunzipSync(buffer, { maxOutputLength: MAX_UNPACKED_BYTES });
  if (tar.length > MAX_UNPACKED_BYTES) throw new Error('offline Wiki package exceeds the extraction limit');
  const root = path.resolve(destination);
  fs.mkdirSync(root, { recursive: true });
  let offset = 0;
  let files = 0;
  let totalBytes = 0;

  while (offset + 512 <= tar.length) {
    const header = tar.subarray(offset, offset + 512);
    if (header.every(byte => byte === 0)) break;

    const storedChecksum = octalField(header, 148, 8);
    let calculatedChecksum = 0;
    for (let i = 0; i < 512; i++) {
      calculatedChecksum += (i >= 148 && i < 156) ? 32 : header[i];
    }
    if (storedChecksum && storedChecksum !== calculatedChecksum) {
      throw new Error('invalid tar header checksum');
    }
    const name = textField(header, 0, 100);
    const prefix = textField(header, 345, 155);
    const relative = prefix ? prefix + '/' + name : name;
    const size = octalField(header, 124, 12);
    const type = String.fromCharCode(header[156] || 48);
    const dataStart = offset + 512;
    const dataEnd = dataStart + size;
    if (dataEnd > tar.length) throw new Error('truncated offline Wiki tar package');

    const target = safeTarget(root, relative);
    if (type === '5') {
      fs.mkdirSync(target, { recursive: true });
    } else if (type === '0' || type === '\0' || type === '7') {
      fs.mkdirSync(path.dirname(target), { recursive: true });
      fs.writeFileSync(target, tar.subarray(dataStart, dataEnd), { flag: 'wx' });
      files++;
      totalBytes += size;
    } else {
      throw new Error('unsupported tar entry type in offline Wiki package');
    }

    offset = dataStart + Math.ceil(size / 512) * 512;
  }

  if (!files || !fs.existsSync(path.join(root, 'kits', 'registry.json'))) {
    throw new Error('offline Wiki package does not contain kits/registry.json');
  }
  return { files, totalBytes };
}

function sha256(buffer) {
  return crypto.createHash('sha256').update(buffer).digest('hex');
}

function verifyKit(kitsRoot, expectedGameId) {
  const registryPath = path.join(kitsRoot, 'registry.json');
  if (!fs.existsSync(registryPath)) throw new Error('offline Wiki registry is missing');
  const registry = JSON.parse(fs.readFileSync(registryPath, 'utf8'));
  const entries = Array.isArray(registry.kits) ? registry.kits : [];
  const entry = entries.find(item => normalizeGameId(item && item.gameId) === normalizeGameId(expectedGameId));
  if (!entry) throw new Error('requested game is not present in offline Wiki registry');

  const dirName = String(entry.dir || entry.gameId || '');
  if (!/^[A-Za-z0-9_-]{1,100}$/.test(dirName)) throw new Error('invalid offline Wiki kit directory');
  const kitDir = path.join(kitsRoot, dirName);
  const manifestPath = path.join(kitDir, 'manifest.json');
  const sumsPath = path.join(kitDir, 'SHA256SUMS.txt');
  if (!fs.existsSync(manifestPath) || !fs.existsSync(sumsPath)) {
    throw new Error('offline Wiki manifest or checksum list is missing');
  }
  const manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf8'));
  if (normalizeGameId(manifest.gameId) !== normalizeGameId(expectedGameId)) {
    throw new Error('offline Wiki manifest gameId mismatch');
  }
  if (!manifest.counts || !Number.isInteger(manifest.counts.pages) || manifest.counts.pages < 1) {
    throw new Error('offline Wiki manifest has invalid page count');
  }
  if (!manifest.index || !Array.isArray(manifest.index.postings) || !manifest.index.postings.length) {
    throw new Error('offline Wiki search index is missing');
  }

  const sums = fs.readFileSync(sumsPath, 'utf8').split(/\r?\n/u).filter(Boolean);
  const listed = new Set();
  let checked = 0;
  for (const line of sums) {
    const match = /^([a-f0-9]{64})\s+(.+)$/i.exec(line);
    if (!match) throw new Error('invalid checksum line in offline Wiki kit');
    const relative = match[2].replace(/^\.\//, '').replace(/\\/g, '/');
    if (listed.has(relative)) throw new Error('duplicate checksum entry in offline Wiki kit: ' + relative);
    listed.add(relative);
    const filePath = safeTarget(kitDir, relative);
    if (!fs.existsSync(filePath) || !fs.statSync(filePath).isFile()) {
      throw new Error('offline Wiki kit file is missing: ' + relative);
    }
    const actual = sha256(fs.readFileSync(filePath));
    if (actual.toLowerCase() !== match[1].toLowerCase()) {
      throw new Error('offline Wiki checksum mismatch: ' + relative);
    }
    checked++;
  }
  if (checked < 10) throw new Error('offline Wiki checksum list is unexpectedly short');

  // The checksum manifest must cover every regular file in the kit, not only
  // an arbitrary subset supplied by the package.
  function assertCompleteCoverage(dir, relativeRoot) {
    for (const item of fs.readdirSync(dir, { withFileTypes: true })) {
      const absolute = path.join(dir, item.name);
      const relative = relativeRoot ? relativeRoot + '/' + item.name : item.name;
      if (item.isDirectory()) {
        assertCompleteCoverage(absolute, relative);
      } else if (item.isFile()) {
        if (relative !== 'SHA256SUMS.txt' && !listed.has(relative)) {
          throw new Error('offline Wiki file is not covered by checksums: ' + relative);
        }
      } else {
        throw new Error('unsupported file type inside offline Wiki kit: ' + relative);
      }
    }
  }
  assertCompleteCoverage(kitDir, '');

  return { entry, manifest, checksumFiles: checked, kitDir };
}

function createOfflineWikiBridge(options) {
  const opts = options || {};
  const getActivePointer = opts.getActivePointer;
  const getBundle = opts.getBundle;
  const cacheRoot = opts.cacheRoot || DEFAULT_CACHE_ROOT;
  const now = opts.now || Date.now;
  if (typeof getActivePointer !== 'function' || typeof getBundle !== 'function') {
    throw new Error('offline Wiki bridge requires getActivePointer and getBundle');
  }

  const activeCache = new Map();
  const activeInflight = new Map();
  const engines = new Map();
  const loading = new Map();

  async function activePointer(gameId) {
    const id = String(gameId);
    const current = activeCache.get(id);
    if (current && now() - current.at < ACTIVE_CACHE_TTL_MS) return current.value;
    if (activeInflight.has(id)) return activeInflight.get(id);
    const promise = Promise.resolve(getActivePointer(id))
      .then(value => {
        activeCache.set(id, { at: now(), value: value || null });
        return value || null;
      })
      .finally(() => activeInflight.delete(id));
    activeInflight.set(id, promise);
    return promise;
  }

  function engineKey(id, version) { return id + '|' + version; }

  async function loadEngine(id, pointer, downloadTimeoutMs) {
    const version = String(pointer.version || '');
    const key = engineKey(id, version);
    if (engines.has(key)) {
      const engine = engines.get(key);
      engines.delete(key);
      engines.set(key, engine);
      return engine;
    }
    if (loading.has(key)) return loading.get(key);

    const promise = (async () => {
      const bundleKey = 'games/' + id + '/wiki/versions/' + version + '/kit.tar.gz';
      const packageBuffer = await getBundle(bundleKey, downloadTimeoutMs || 8000);
      if (!Buffer.isBuffer(packageBuffer) || !packageBuffer.length) {
        throw new Error('offline Wiki package object is missing');
      }
      const actualSha = sha256(packageBuffer);
      if (actualSha.toLowerCase() !== String(pointer.sha256 || '').toLowerCase()) {
        throw new Error('offline Wiki package SHA256 mismatch');
      }

      const target = path.join(cacheRoot, id, version);
      const marker = path.join(target, '.moon-kit-ready.json');
      let extracted = false;
      if (fs.existsSync(marker)) {
        try {
          const ready = JSON.parse(fs.readFileSync(marker, 'utf8'));
          extracted = ready.sha256 === actualSha;
        } catch {}
      }
      if (!extracted) {
        fs.rmSync(target, { recursive: true, force: true });
        fs.mkdirSync(target, { recursive: true });
        extractTarGz(packageBuffer, target);
        const verification = verifyKit(path.join(target, 'kits'), pointer.kitGameId || id);
        if (pointer.pages != null && Number(pointer.pages) !== verification.manifest.counts.pages) {
          throw new Error('offline Wiki pointer page count does not match kit manifest');
        }
        if (pointer.language && String(pointer.language).toLowerCase() !== String(verification.manifest.language || '').toLowerCase()) {
          throw new Error('offline Wiki pointer language does not match kit manifest');
        }
        fs.writeFileSync(marker, JSON.stringify({
          sha256: actualSha,
          checksumFiles: verification.checksumFiles,
          pages: verification.manifest.counts.pages,
          builtAt: verification.manifest.builtAt || null
        }));
      }

      const kitsRoot = path.join(target, 'kits');
      const engine = createOfflineWiki({ kitsRoot });
      const games = engine.listGames();
      if (!games.some(item => normalizeGameId(item.gameId) === normalizeGameId(pointer.kitGameId || id))) {
        throw new Error('offline Wiki engine cannot see requested game');
      }
      return engine;
    })().then(engine => {
      engines.set(key, engine);
      while (engines.size > MAX_ENGINE_CACHE) engines.delete(engines.keys().next().value);
      return engine;
    }).finally(() => loading.delete(key));

    loading.set(key, promise);
    return promise;
  }

  return {
    async search(params) {
      const body = params || {};
      // The KE passes its already-normalized storage id. Keep Unicode ids
      // intact (the engine's kitGameId may be a separate ASCII registry id).
      const id = String(body.gameId || body.game || '').trim().toLowerCase();
      if (!id || !/^[\p{L}\p{N}_-]{1,80}$/u.test(id) || id.includes('..')) {
        return { status: 'not_installed', gameId: id || 'unknown-game', results: [] };
      }
      const query = String(body.query || body.q || '').trim();
      if (!query) throw new Error('query is required');

      const pointer = await activePointer(id);
      if (!pointer || pointer.status !== 'active') {
        return { status: 'not_installed', gameId: id, results: [] };
      }
      if (pointer.schemaVersion !== 1 || pointer.gameId !== id ||
          !VERSION_RE.test(String(pointer.version || '')) ||
          !SHA256_RE.test(String(pointer.sha256 || ''))) {
        return { status: 'invalid_pointer', gameId: id, results: [] };
      }

      try {
        const fast = body.fast === true || body.fast === 1 || body.fast === '1' || body.fast === 'true';
        const engine = await loadEngine(id, pointer, fast ? 2500 : 12000);
        const payload = engine.search({
          gameId: pointer.kitGameId || id,
          query,
          limit: body.limit || (body.fast ? 2 : 5),
          includeFullText: body.includeFullText === true
        });
        if (payload && payload.status === 'ok' && Array.isArray(payload.results) && payload.results.length) {
          return Object.assign({}, payload, {
            gameId: id,
            search: Object.assign({}, payload.search, {
              mode: 'offline-kit',
              fast: body.fast === true || body.fast === 1 || body.fast === '1' || body.fast === 'true',
              offlineVersion: pointer.version,
              offlineSha256: pointer.sha256
            })
          });
        }
        return Object.assign({}, payload || {}, { status: 'no_evidence', gameId: id });
      } catch (error) {
        return {
          status: 'unavailable',
          gameId: id,
          results: [],
          errorCode: 'offline_kit_load_failed'
        };
      }
    },
    async prepare(gameId) {
      const id = String(gameId || '').trim().toLowerCase();
      if (!id || !/^[\p{L}\p{N}_-]{1,80}$/u.test(id) || id.includes('..')) {
        return { status: 'bad_game_id' };
      }
      const pointer = await activePointer(id);
      if (!pointer || pointer.status !== 'active') return { status: 'not_installed', gameId: id };
      if (pointer.schemaVersion !== 1 || pointer.gameId !== id ||
          !VERSION_RE.test(String(pointer.version || '')) ||
          !SHA256_RE.test(String(pointer.sha256 || ''))) {
        return { status: 'invalid_pointer', gameId: id };
      }
      try {
        const engine = await loadEngine(id, pointer, 30000);
        const kitGameId = pointer.kitGameId || id;
        const manifest = engine.manifest(kitGameId);
        if (!manifest) throw new Error('manifest not found after load');
        return {
          status: 'ready',
          gameId: id,
          version: pointer.version,
          kitGameId,
          pages: manifest.counts.pages,
          language: manifest.language,
          source: manifest.source && manifest.source.siteName || '',
          archiveSha256: pointer.sha256
        };
      } catch (error) {
        return { status: 'unavailable', gameId: id, errorCode: 'offline_kit_load_failed' };
      }
    },
    clearActiveCache(gameId) {
      if (gameId) activeCache.delete(String(gameId));
      else activeCache.clear();
    }
  };
}

module.exports = {
  createOfflineWikiBridge,
  extractTarGz,
  verifyKit,
  _internal: { normalizeGameId, safeTarget, sha256 }
};
