# Moon Knowledge Engine 0.10.10 — install candidate

Status: local validation candidate; not deployed.

Changes vs 0.10.9:
- Synchronizes the offline search engine with the current universal 1.0.0 kit builder.
- Keeps the low-memory Kit store from the deployed KE line (one shard + one postings bucket cache).
- Fixes false positive topic matching observed through the KE bridge: the Witcher pack no longer treats a page mentioning only “Джонни” as evidence for “Джонни Сильверхенд”.
- Keeps the existing KE bridge, Object Storage key scheme, and live-Wiki fallback unchanged.
- Aligns the ping-reported `KB_VERSION`, package.json and VERSION to 0.10.10.

Settings remain the same: Node.js 22, handler index.handler, 512 MB, timeout 60 seconds. No new environment variables.

This ZIP contains function code only. Game kits remain separate in Object Storage.
