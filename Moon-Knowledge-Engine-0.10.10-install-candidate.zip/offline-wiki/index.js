'use strict';

// Moon offline Wiki search — engine over ZIM-derived kits.
// Node.js 22+, zero npm dependencies, no native modules.
//
// The engine is game-agnostic: every kit is described by kits/registry.json
// and its own manifest.json. Nothing here knows about a specific title,
// character or location.

const path = require('path');

const { Registry, normalizeGameId } = require('./lib/store');
const { normalize, tokenize, uniqueTokens, STOPWORDS } = require('./lib/text');

const DEFAULT_LIMIT = 5;
const MAX_LIMIT = 10;
const MAX_QUERY = 300;
const EVIDENCE_MAX = 600;
const CANDIDATE_LIMIT = 40;
const MENTION_MIN_TF = 3;
const DEFAULT_ROOT = process.env.MOON_OFFLINE_WIKI_ROOT ||
  path.join(__dirname, 'kits');

// ---------------------------------------------------------------- helpers

function bm25(tf, dl, avgdl, idfValue) {
  const k1 = 1.2;
  const b = 0.75;
  const denom = tf + k1 * (1 - b + b * (dl / Math.max(1, avgdl)));
  return (idfValue * (tf * (k1 + 1))) / denom;
}

function editDistance(a, b, max) {
  if (Math.abs(a.length - b.length) > max) return max + 1;
  const prev = new Array(b.length + 1);
  const cur = new Array(b.length + 1);
  for (let j = 0; j <= b.length; j++) prev[j] = j;
  for (let i = 1; i <= a.length; i++) {
    cur[0] = i;
    let best = cur[0];
    for (let j = 1; j <= b.length; j++) {
      const cost = a[i - 1] === b[j - 1] ? 0 : 1;
      cur[j] = Math.min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + cost);
      if (cur[j] < best) best = cur[j];
    }
    if (best > max) return max + 1;
    for (let j = 0; j <= b.length; j++) prev[j] = cur[j];
  }
  return prev[b.length];
}

function wordClose(a, b) {
  if (a === b) return 0;
  const max = Math.max(a.length, b.length) >= 8 ? 2 : 1;
  if (Math.abs(a.length - b.length) > max) return Infinity;
  const dist = editDistance(a, b, max);
  return dist <= max ? dist : Infinity;
}

function extractPhrase(query) {
  const match = String(query).match(/[«"“„']([^»"”„']{2,90})[»"”„']/u);
  return match ? normalize(match[1]) : '';
}

function fuzzyTerms(kit, token) {
  const maxDist = token.length <= 4 ? 1 : 2;
  const hits = [];
  for (const term of kit.vocab().keys()) {
    if (Math.abs(term.length - token.length) > maxDist) continue;
    if (token.length > 3 && term.charAt(0) !== token.charAt(0)) continue;
    const dist = editDistance(token, term, maxDist);
    if (dist <= maxDist) hits.push([term, dist]);
  }
  hits.sort((a, b) => a[1] - b[1] || b[0].length - a[0].length);
  return hits.slice(0, 3).map(hit => hit[0]);
}

function titleKeys(kit) {
  if (!kit.__titleKeyById) {
    const keys = new Array(kit.docs().length);
    for (const doc of kit.docs()) keys[doc.id] = uniqueTokens(doc.title).join(' ');
    kit.__titleKeyById = keys;
  }
  return kit.__titleKeyById;
}

function splitWindows(text, size) {
  const clean = String(text || '').trim();
  if (!clean) return [];
  if (clean.length <= size) return [clean];
  const sentences = clean.split(/(?<=[.!?…])\s+/u);
  const windows = [];
  let buf = '';
  for (const sentence of sentences) {
    if (!buf) {
      buf = sentence;
    } else if (buf.length + sentence.length + 1 <= size) {
      buf += ' ' + sentence;
    } else {
      windows.push(buf);
      buf = sentence;
    }
    while (buf.length > size * 2) {
      const cut = buf.lastIndexOf(' ', size);
      const at = cut > size / 2 ? cut : size;
      windows.push(buf.slice(0, at));
      buf = buf.slice(at).trim();
    }
  }
  if (buf) windows.push(buf);
  return windows;
}

function pickEvidence(kit, page, qTokens, phrase, options) {
  const opts = options || {};
  const sections = Array.isArray(page.sections) && page.sections.length
    ? page.sections
    : [{ h: '', text: page.text || '' }];
  const wanted = new Set(qTokens);
  let best = null;

  // An article whose title is the answer talks about it right from the lead.
  if (opts.preferLead) {
    for (const section of sections) {
      if (/^инфобокс$/iu.test(section.h || '')) continue;
      const text = String(section.text || '').trim();
      if (!text) continue;
      const first = splitWindows(text, 420)[0] || text;
      const stems = new Set(tokenize(first));
      const hit = qTokens.some(token => stems.has(token)) ||
        (phrase && normalize(first).includes(phrase));
      if (hit) {
        return { score: 4, text: first.slice(0, EVIDENCE_MAX), section: section.h || '' };
      }
      break;
    }
  }

  for (let si = 0; si < sections.length; si++) {
    const section = sections[si];
    const headingStems = new Set(tokenize(section.h || ''));
    const windows = splitWindows(section.text, 420);
    for (let wi = 0; wi < windows.length; wi++) {
      const text = windows[wi];
      const stems = new Set(tokenize(text));
      let matched = 0;
      for (const token of wanted) if (stems.has(token)) matched++;
      const phraseHit = phrase && normalize(text).includes(phrase);
      if (!matched && !phraseHit) continue;
      let score = matched * 2;
      if (phraseHit) score += 3;
      if (si < 2) score += 1.2;
      if (wi === 0) score += 0.4;
      for (const token of wanted) if (headingStems.has(token)) score += 1.5;
      if (/^инфобокс$/iu.test(section.h || '')) score -= 6;
      if (!best || score > best.score) {
        best = { score, text, section: section.h || '', sectionIndex: si };
      }
    }
  }

  if (!best) {
    const fallback = String(page.text || '').trim();
    return fallback
      ? { score: 0, text: fallback.slice(0, EVIDENCE_MAX), section: '' }
      : { score: 0, text: '', section: '' };
  }

  let text = best.text.trim();
  const full = String(sections[best.sectionIndex] && sections[best.sectionIndex].text || '');
  if (full && text.length < full.length) {
    if (normalize(full).indexOf(normalize(text)) > 0) text = '… ' + text;
    if (normalize(full).indexOf(normalize(text)) + normalize(text).length < normalize(full).length) {
      text = text + ' …';
    }
  }
  return {
    score: best.score,
    text: text.slice(0, EVIDENCE_MAX),
    section: best.section,
  };
}

// ---------------------------------------------------------------- ranking

function collectCandidates(kit, qTokens) {
  const docs = kit.docs();
  const total = docs.length;
  const avgdl = (kit.manifest.index && kit.manifest.index.avgDocLen) || 1;
  const vocab = kit.vocab();
  const titleTerms = kit.titleTerms();
  const scores = new Map();

  const ensure = id => {
    let entry = scores.get(id);
    if (!entry) {
      entry = { id, content: 0, title: 0, matched: new Set(), tfMax: 0 };
      scores.set(id, entry);
    }
    return entry;
  };

  for (const token of qTokens) {
    const variants = [];
    if (vocab.has(token)) {
      variants.push([token, 1]);
    } else {
      for (const near of fuzzyTerms(kit, token)) variants.push([near, 0.65]);
    }
    for (const [term, weight] of variants) {
      const df = vocab.get(term) || 1;
      const idfValue = Math.log(1 + (total - df + 0.5) / (df + 0.5)) * weight;
      const postings = kit.terms(term) || [];
      for (const [id, tf] of postings) {
        const entry = ensure(id);
        const dl = docs[id] ? docs[id].len : avgdl;
        entry.content += bm25(tf, dl, avgdl, idfValue);
        if (tf > entry.tfMax) entry.tfMax = tf;
        entry.matched.add(token);
      }
      for (const [id, tf] of titleTerms[term] || []) {
        const entry = ensure(id);
        entry.title += idfValue * (1 + Math.log(tf)) * 2.2;
        entry.matched.add(token);
      }
    }
  }
  return scores;
}

function scoreCandidates(kit, scores, qTokens, qWords, qKey, phrase) {
  const docs = kit.docs();
  const keys = titleKeys(kit);
  const exactTitleId = qKey ? kit.titleStemMap().get(qKey) : undefined;
  const aliasId = qKey ? kit.aliasStemMap().get(qKey) : undefined;
  const out = [];

  for (const entry of scores.values()) {
    const doc = docs[entry.id];
    if (!doc) continue;
    const tkey = keys[entry.id] || '';
    const coverage = qTokens.length ? entry.matched.size / qTokens.length : 0;
    let score = entry.content + entry.title;

    const titleExact = exactTitleId === entry.id || (qKey && tkey === qKey);
    const aliasExact = aliasId === entry.id;
    const titleStarts = qKey && tkey.startsWith(qKey) && qKey.length >= 3;
    const titleContains = qKey && tkey.includes(qKey);

    // Whole-query fuzzy title match: a name typed with one or two wrong
    // letters still resolves to the article that carries that name.
    const titleWords = normalize(doc.title).split(' ').filter(Boolean);
    let titleFuzzy = qWords.length > 0;
    if (titleFuzzy) {
      for (const word of qWords) {
        if (!titleWords.some(candidate => wordClose(word, candidate) !== Infinity)) {
          titleFuzzy = false;
          break;
        }
      }
    }

    if (titleExact) score = Math.max(score, 500) + 250;
    else if (aliasExact) score = Math.max(score, 380) + 150;
    else if (titleFuzzy) score = Math.max(score, 460) + 120;
    else if (titleStarts) score += 90;
    else if (titleContains) score += 35;

    score *= 0.45 + 0.55 * coverage;

    // A mention only counts as a topic when the title matches, or when the
    // article really covers the query: every word of a short query, or most
    // words of a long one, and repeated mentions for single-word lookups.
    const topicMatch = titleExact || aliasExact || titleContains || titleFuzzy;
    const repeatedMention = entry.tfMax >= MENTION_MIN_TF;
    const enoughCoverage = qTokens.length === 1
      ? repeatedMention
      : (coverage >= 0.6 && (repeatedMention || coverage === 1));
    if (!topicMatch && !enoughCoverage) continue;

    out.push({
      id: entry.id,
      score,
      coverage,
      titleExact: !!titleExact,
      aliasExact: !!aliasExact,
      phrase,
    });
  }

  out.sort((a, b) => b.score - a.score);
  return out;
}

// ---------------------------------------------------------------- public API

function searchKit(kit, params) {
  const query = String(params.query || '').trim().slice(0, MAX_QUERY);
  const limit = Math.min(MAX_LIMIT, Math.max(1, Number(params.limit) || DEFAULT_LIMIT));
  const phrase = extractPhrase(query);
  const qTokens = uniqueTokens(query);
  const qWords = normalize(query).split(' ').filter(word => word && !STOPWORDS.has(word));
  const qKey = qTokens.join(' ');
  const manifest = kit.manifest;

  const payloadBase = {
    gameId: manifest.gameId,
    game: manifest.game,
    gameVersion: manifest.gameVersion || 'unspecified',
    edition: manifest.edition || 'unspecified',
    database: {
      status: 'offline',
      pages: manifest.counts.pages,
      complete: true,
      warmReady: true,
      note: 'Ответы формируются по локальному офлайн-комплекту, собранному из ZIM.',
    },
    intent: { name: 'offline-lookup', section: '' },
    comparison: null,
    warm: { ready: true, status: 'ready', pages: manifest.counts.pages },
    search: {
      mode: 'offline-kit',
      fast: true,
      queryVariants: qTokens,
      fetchedPages: 0,
      errors: [],
    },
  };

  if (!qTokens.length && !phrase) {
    return Object.assign({}, payloadBase, {
      status: 'no_evidence',
      results: [],
      reason: 'empty_query',
    });
  }

  const effective = qTokens.length ? qTokens : uniqueTokens(phrase);
  const scores = collectCandidates(kit, effective);
  const ranked = scoreCandidates(kit, scores, effective, qWords, qKey, phrase);

  const evaluated = [];
  for (const candidate of ranked.slice(0, CANDIDATE_LIMIT)) {
    const page = kit.page(candidate.id);
    if (!page) continue;
    const picked = pickEvidence(kit, page, effective, phrase, {
      preferLead: candidate.titleExact || candidate.aliasExact,
    });
    const phraseHit = phrase && normalize(page.text).includes(phrase);
    const categoryStems = new Set();
    for (const category of page.categories || []) {
      for (const stem of tokenize(category)) categoryStems.add(stem);
    }
    let categoryHits = 0;
    for (const token of effective) if (categoryStems.has(token)) categoryHits++;
    let finalScore = candidate.score + picked.score * 1.5 + categoryHits * 6;
    if (phraseHit) finalScore += 40;
    if (!picked.text) continue;
    if (!picked.score && !candidate.titleExact && !candidate.aliasExact) continue;

    evaluated.push({
      page,
      score: finalScore,
      evidenceScore: picked.score,
      evidence: picked.text,
      section: picked.section,
      phraseHit: !!phraseHit,
    });
  }

  evaluated.sort((a, b) => b.score - a.score);
  const results = evaluated.slice(0, limit).map(hit => {
    const page = hit.page;
    const result = {
      title: page.title,
      url: page.url,
      revisionId: null,
      categories: page.categories || [],
      score: Math.round(hit.score * 100) / 100,
      evidenceScore: Math.round(hit.evidenceScore * 100) / 100,
      evidenceSection: hit.section || '',
      section: hit.section || '',
      entity: null,
      evidence: hit.evidence,
      contentAvailable: true,
      contentLength: page.length || (page.text || '').length,
      contentSource: 'offline-zim-kit',
      source: manifest.source.siteName,
      language: manifest.language,
      hasFullText: true,
      pageId: page.id,
    };
    if (params.includeFullText) result.text = page.text || '';
    return result;
  });

  return Object.assign({}, payloadBase, {
    status: results.length ? 'ok' : 'no_evidence',
    results,
    search: Object.assign({}, payloadBase.search, {
      fetchedPages: evaluated.length,
    }),
  });
}

function createOfflineWiki(options) {
  const opts = options || {};
  const root = opts.kitsRoot || DEFAULT_ROOT;
  const registry = new Registry(root);

  return {
    kitsRoot: root,
    listGames() {
      return registry.entries().map(entry => ({
        gameId: entry.gameId,
        game: entry.game,
        language: entry.language,
        dir: entry.dir || entry.gameId,
      }));
    },
    manifest(gameId) {
      const kit = registry.get(gameId);
      return kit ? kit.manifest : null;
    },
    page(gameId, pageId) {
      const kit = registry.get(gameId);
      return kit ? kit.page(pageId) : null;
    },
    search(params) {
      const body = params || {};
      const wanted = body.gameId || body.game;
      const kit = registry.get(wanted);
      if (!kit) {
        return {
          status: 'unknown_game',
          gameId: normalizeGameId(wanted),
          message: 'Для этой игры офлайн-комплект не установлен',
          results: [],
        };
      }
      const query = String(body.query || body.q || '').trim();
      if (!query) throw new Error('query is required');
      return searchKit(kit, Object.assign({}, body, { query }));
    },
  };
}

let sharedEngine = null;

function defaultEngine(kitsRoot) {
  if (!sharedEngine || (kitsRoot && sharedEngine.kitsRoot !== kitsRoot)) {
    sharedEngine = createOfflineWiki(kitsRoot ? { kitsRoot } : {});
  }
  return sharedEngine;
}

async function searchOfflineWiki(params) {
  const body = params || {};
  const engine = body.engine || defaultEngine(body.kitsRoot);
  return engine.search(body);
}

function listOfflineGames(kitsRoot) {
  return defaultEngine(kitsRoot).listGames();
}

module.exports = {
  searchOfflineWiki,
  createOfflineWiki,
  listOfflineGames,
  _internal: {
    bm25,
    editDistance,
    extractPhrase,
    fuzzyTerms,
    pickEvidence,
    splitWindows,
    searchKit,
    MENTION_MIN_TF,
  },
};
